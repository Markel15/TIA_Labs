#!/usr/bin/env python
# coding: utf-8

# # Codifica tus própios perceptrones para implementar puertas lógicas
# En las partes que aparecen así
# ```python
# pass  # ⬅️✏️
# ```
# necesitas rellenar código antes de pasar a la siguiente celda.
# 
# Revisa las transparencias de clase para llevar a cabo estos ejercicios.

# ### Comenzaremos por implementar una **neurona AND**. Ojo!! No la vamos a entrenar, vamos a asumir que conocemos los pesos (los hemos calculado en clase) 
# 
# Para ello:
# 
# 1) suponemos que el entrenamiento ya está previamente hecho y por lo tanto conocemos los pesos apropiados (consultar las transparencias)
# 
# 2) Nos piden implementar la neurona AND y probar con un item o ejemplo, por ejemplo un vector de input 0,1 que la salida es correcta
# 
# Recordad que en clase hemos descubierto que los pesos apropiados son:
# 0.66 y 0.8, así que el vector de pesos será [0.66,0.8] y el bias será 1 y el peso para el bias será -0.97

# In[3]:


# Definir dos vectores (listas): input my_x, pesos my_w
my_x = [0, 1]#input un item
my_w = [0.66, 0.80]


# In[4]:


# Multiplicar dos vectores elemento a elemento
def mul(a, b):
    """
    devolver una lista c, de la misma longitud que a y b donde 
    cada elemento c[i] = a[i] * b[i]
    lo podéis hacer con un bucle o con una list comprenhension
    """
    c = []
    for i in range(len(a)):
        c.append(a[i]*b[i])
    return c


# In[5]:


# Test la función mul() con un item my_x 
# y los pesos descubiertos en clase my_w, el resultado debería ser 
# el vector [0.0,0.8]
mul(my_x, my_w)


# In[6]:


# Define el bias my_bias y el peso descubierto en clase asociado a ese bias
# añadiré el bias a el vector de pesos my_w generando un nuevo vector my_wPlusWBias.
# Posibles errores: Recordad que en Python las variables con punteros
# y el insertar si lo ejecutáis varias veces los valores 
# se van acumulando dependiendo de cómo hagáis la inserción
# my_wPlusWBias debería contener [-0.97, 0.66, 0.8]. Pista para hacer copias de un vector. copiaV=v[:] o copiaV=v.copy()

my_bias  = 1
my_wbias = -0.97
my_w = mul(my_x, my_w)
my_wPlusWBias = my_w[:]
my_wPlusWBias.insert(0, my_wbias)  # insertar al final
print(my_wPlusWBias)


# In[7]:


# Neurona lineal
def distanciaDelCoseno(x, weights, bias):
    """
    El producto escalar (producto punto) de dos vectores y la similitud de coseno no son completamente equivalentes 
    ya que la similitud del coseno solo se preocupa por la diferencia de ángulo, 
    mientras que el producto de punto se preocupa por el ángulo y la magnitud
    Pero en muchas ocasiones se emplean indistintamente
    Así pues, esta función devuelve el valor escalar de la neurona, es decir, 
    el producto escalar entre el vector de entrada añadiendo el bias y el vector de los pesos
    recordad que "sum(list)" computa la suma de los elementos de una lista
    Así pues se comenzará por añadir el bías en la posición 0 del vector de entrada 
    antes de llevar a cabo el producto escalar para así tener dos vectores de 
    la misma longitud. Emplea la función mul que ya has programado
    """
    x_bias = x[:]
    x_bias.insert(0, bias)
    # Calcular el producto elemento a elemento usando la función mul
    producto_escalar = mul(x_bias, weights)
    # Calcular la suma de los elementos del producto para obtener el valor escalar
    resultado = sum(producto_escalar)
    return resultado


# In[8]:


# Test distanciaDelCoseno que debería darte -0.16999999999999993 para los datos my_x, my_wPlusWBias, my_bias
distanciaDelCoseno(my_x, my_wPlusWBias, my_bias)


# In[9]:


# Una neurona perceptron completa, distancia del coseno y activación
def neuron(x, weights, bias):
    """
    Devolverá el output de una neurona clásica 
    (reutilizar la distancia del coseno definida previamente) 
    y añadir la función de activación (step function): si >=0 entonces 1 sino -1
    """
    producto_escalar = distanciaDelCoseno(x, weights, bias)
    # Aplicar la función de activación (step function)
    if producto_escalar >= 0:
        output = 1
    else:
        output = -1
    return output    


# In[10]:


# Testar la función neuron() para el item my_x y el bias my_b 
# y el vector de pesos my_wPlusWBias
# debería de dar -1 para el input item [0,1] con el bias 1 
# y el vector de pesos hallado en clase
neuron(my_x, my_wPlusWBias, my_bias)


# In[11]:


# Package AND neuron weights and bias
def and_neuron(x):
    """
    Devuelve x1 AND x2 suponiendo que la hemos entrenado
    y que en ese entrenamiento hemos aprendido los pesos apropiados 
    (mirar las transparencias de clase). Así pues inicializaremos 
    una la variable local and_w con los pesos aprendidos 
    y a 1 la variable local and_bias 
    y ejecutaremos la función neurona para el item x"""
    and_w    = [-0.97,0.66, 0.80]#initialization of the weights and_w
    and_bias = 1#initialization of the bias and_bias
    # Llamar a la función de la neurona con los pesos y bias específicos de la puerta AND
    return neuron(x, and_w, and_bias)


# Ahora nos piden probar la puerta para toda la colección de inputs posibles

# In[13]:


# Se definen los items de entrada para testar
# las neuronas AND y las posteriores que implementaremos (OR, XOR)
# CUIDADO para la neurona NOT hará falta otra colección dado 
# que los vectores de entrada a la NOT no tienen dos dimensiones sino 1
my_x_collection = [
    [0, 0],
    [0, 1],
    [1, 0],
    [1, 1],
]


# In[14]:


# Para los items de entrada my_x_collection la salida debería ser 
# -1, -1, -1, 1
print('Testando el output de la neurona AND')
#bucle para ir obteniendo el output de la neurona AND para cada item del input
for my_x in my_x_collection:
    print(my_x, f'{and_neuron(my_x):.3f}')


# ### Neurona OR
# 
# Hasta ahora solo habéis tenido que implementar la neurona AND sin tener que entrenarla dado que ya conocíamos los pesos que habíamos aprendido en clase. Es decir, no habéis implementado en Python la fase de entrenamiento de la neurona para determinar los pesos. Ahora se os pide que entrenéis una neurona OR, de forma que realicéis iteraciones sobre los items del input. Para ello los pasos serán:
# 1) Inicializar un vector de pesos de forma random (emplear la librería random **from random import random**)
# 
# 2) Por cada item del input aplicar la neurona y si la predicción realizada por la neurona en base a aplicar  la distancia del coseno y la función de activación no es correcta, entonces ajustar los pesos consecuentemente
# 
# 3) Repetir el paso 2 hasta convergencia (es decir, hasta que todos los items estén correctamente clasificados)

# In[16]:


from random import seed
from random import random

#inicializaciones
print('Entrenando una neurona OR hasta convergencia')
notConverge=True
seed(1)# Si queremos que el proceso de inicialización random sea replicable
orWeights= [random() for i in range(3)]#inicializar de forma random el vector de pesos or_weights
print("Imprimiendo los pesos random", orWeights, "\n")
orBias   = 1#inicialización del bias a 1
orGoldOutputs=[-1,1,1,1]#inicialización del Gold Standard o patrón oro, 
# es decir, el output que la neurona OR debería aprender a obtener

#entrenando
numeroVuelta = 0
while notConverge:
    notConverge = False  # Suponemos inicialmente que convergerá en esta vuelta
    numeroVuelta += 1
    print(f"\n### Estamos en la vuelta (epoch) {numeroVuelta}")
    for i, x in enumerate(my_x_collection):
        print("Imprimiendo los pesos")
        print(orWeights)
    
        prediccion = neuron(x, orWeights, orBias)
        
        # Mostrar la predicción y el valor esperado
        print(f"predictedOutput:{prediccion} Gold {orGoldOutputs[i]}")

        # Calcular el error
        error = orGoldOutputs[i] - prediccion

        # Si hay error, ajustar los pesos
        if error != 0:
            notConverge = True  # No ha convergido, continuaremos entrenando
            print("  Se han cambiado los pesos")

            # Ajustar pesos y bias
            orWeights[0] += (orGoldOutputs[i] * orBias)  # Ajuste del peso del bias
            for j in range(2):
                orWeights[j + 1] += (orGoldOutputs[i] * x[j])  # Ajuste de los pesos de entrada
            
            # Mostrar pesos actualizados
            print(orWeights)


# ### Neurona NOT
# 
# Ahora implementa el entrenamiento de una neurona NOT

# In[18]:


# Se definen los items de entrada para testar
# la neurona NOT. 
# Recordad que los vectores de entrada a la NOT no tienen dos dimensiones sino 1
my_x_collection = [
    [0],
    [1]
]


# In[19]:


from random import seed
from random import random


#inicializaciones
print('Entrenando una neurona NOT hasta convergencia')
notConverge=True
seed(1)# Si queremos que el proceso de inicialización random sea replicable
#inicializar de forma random el vector de pesos notWeights
notWeights= [random() for i in range(2)]

print("Imprimiendo los pesos random", notWeights, "\n")
notBias   = 1#inicialización del bias a 1
#inicialización del Gold Standard o patrón oro,notGoldOutput. CUIDADO con el número de valores que ponéis 
# es decir, el output que la neurona OR debería aprender a obtener
notGoldOutputs=[1,-1]#inicialización del Gold Standard o patrón oro, 

#entrenando
numeroVuelta = 0
while notConverge:
    notConverge = False  # Suponemos inicialmente que convergerá en esta vuelta
    numeroVuelta += 1
    print(f"\n### Estamos en la vuelta (epoch) {numeroVuelta}")
    for i, x in enumerate(my_x_collection):
        print("Imprimiendo los pesos")
        print(notWeights)
        
        # Calcular la predicción de la neurona OR con los pesos actuales
        prediccion = neuron(x, notWeights, notBias)
        
        # Mostrar la predicción y el valor esperado
        print(f"predictedOutput:{prediccion} Gold {notGoldOutputs[i]}")
        # Si hay error, ajustar los pesos
        if prediccion != notGoldOutputs[i]:
            notConverge = True  # No ha convergido, continuaremos entrenando
            print("  Se han cambiado los pesos")
            
            # Ajustar pesos y bias
            notWeights[0] += (notGoldOutputs[i]* notBias)  # Ajuste del peso del bias
            notWeights[1] += (notGoldOutputs[i] * x[0])  # Ajuste de los pesos de entrada
            
            # Mostrar pesos actualizados
            print(notWeights)


# ### Weighted average
# 
# Ahora implementa el weighted average explicado en las transparencias de clase ¿qué puedes decir acerca de las actualizaciones de los pesos y el número de epochs?

# In[21]:


# Se definen los items de entrada para testar
# las neuronas AND y las posteriores que implementaremos (OR, XOR)
# CUIDADO para la neurona NOT hará falta otra colección dado 
# que los vectores de entrada a la NOT no tienen dos dimensiones sino 1
my_x_collection = [
    [0, 0],
    [0, 1],
    [1, 0],
    [1, 1],
]


# In[22]:


def matrixAverage(m):
    res=list()
    acum=list()
    if len(m) > 0:
        res=[0]*len(m[0])
        for v in m:
            res = [a+b for a,b in zip (res,v)]
        acum=[elem/len(m) for elem in res]
    return acum


# In[23]:


matrix=[[2,3,4],[2,3,4],[2,3,4]]
print(matrixAverage(matrix))


# In[24]:


from random import seed
from random import random

#inicializaciones
print('Entrenando una neurona OR hasta convergencia')
notConverge=True
seed(1)# Si queremos que el proceso de inicialización random sea replicable
orWeights= [random() for i in range(3)]#inicializar de forma random el vector de pesos or_weights
print("Imprimiendo los pesos random", orWeights, "\n")
orBias   = 1#inicialización del bias a 1
orGoldOutputs=[-1,1,1,1]#inicialización del Gold Standard o patrón oro, 
# es decir, el output que la neurona OR debería aprender a obtener
weightLength = len(orWeights) 
#entrenando
numeroVuelta = 0
while notConverge:
    notConverge = False  # Suponemos inicialmente que convergerá en esta vuelta
    numeroVuelta += 1
    print(f"\n### Estamos en la vuelta (epoch) {numeroVuelta}")
    for i, x in enumerate(my_x_collection):
        print("Imprimiendo los pesos")
        print(orWeights)
        
        # Calcular la predicción de la neurona OR con los pesos actuales

        x_with_bias = [1] + x  # Añadimos el bias como primera entrada
        weighted_sum = sum(w * x for w, x in zip(orWeights, x_with_bias))
        prediccion = 1 if weighted_sum > 0 else -1
        
        # Mostrar la predicción y el valor esperado
        print(f"predictedOutput:{prediccion} Gold {orGoldOutputs[i]}")

        # Calcular el error
        error = orGoldOutputs[i] - prediccion

        # Si hay error, ajustar los pesos
        if error != 0:
            notConverge = True  # No ha convergido, continuaremos entrenando
            print(x)
            print("AuxAct")
            auxAct = [w - x for w, x in zip(orWeights, x_with_bias)]
            print(auxAct)
            print("  Se han añadido pesos")
            print(orWeights)
            newWeights = [w + x for w, x in zip(orWeights, auxAct)]
            print(newWeights)
            print("acum")
            acum = matrixAverage([auxAct, orWeights])
            print(acum)
            print(acum)
            print(orWeights)
            print(newWeights)
            print("acum")
            acum = matrixAverage([auxAct, orWeights])
            orWeights = acum
            # Mostrar pesos actualizados
            print(orWeights)


# In[25]:


# Package OR neuron weights and bias
def or_neuron(x):
    """
    Devuelve x1 AND x2 suponiendo que la hemos entrenado
    y que en ese entrenamiento hemos aprendido los pesos apropiados 
    (mirar las transparencias de clase). Así pues inicializaremos 
    una la variable local and_w con los pesos aprendidos 
    y a 1 la variable local and_bias 
    y ejecutaremos la función neurona para el item x"""
    or_w    = [-0.3656,0.8474, 0.7637]#initialization of the weights and_w
    or_bias = 1#initialization of the bias and_bias
    #pass  # ⬅️✏️
    prediccion = neuron(x, or_w, or_bias)
    return prediccion


# In[26]:


# Para los items de entrada my_x_collection la salida debería ser 
# -1, -1, -1, 1      ????????????  <-(estaba escrito así al descargar) Si es OR debería ser -1, 1, 1, 1
print('Testando el output de la neurona OR')
#bucle para ir obteniendo el output de la neurona AND (???? o quiere decir OR?) para cada item del input
for my_x in my_x_collection:
    print(my_x, f'{or_neuron(my_x):.3f}')


# ![X-OR](res/xorToLearnWeights.png)

# In[71]:


# Combinando una puerta OR y una AND, y aprendiendo el peso que hay que darle a cada una para obtener un XOR 
from random import seed
from random import random

#inicializaciones
print('Entrenando una neurona XOR hasta convergencia')
xorConverge=True
seed(1)# Si queremos que el proceso de inicialización random sea replicable
xorWeights= [random() for i in range(3)]#inicializar de forma random el vector de pesos or_weights
print("Imprimiendo los pesos random", xorWeights, "\n")
xorBias   = -0.5#inicialización del bias a 0.5
xorGoldOutputs=[1,-1,-1,1]#inicialización del Gold Standard o patrón oro, 
# es decir, el output que la red XOR debería aprender a obtener
#entrenando
numeroVuelta = 0

def calcular_salida_xor(x, weights, bias):
    # Obtener las salidas de OR y AND para las entradas
    lista = [and_neuron(x)] + [or_neuron(x)]
    print(lista)
    respuesta=[bias]+lista
    return respuesta
    
while xorConverge:
    xorConverge = False  # Suponemos inicialmente que convergerá en esta vuelta
    numeroVuelta += 1
    print(f"\n### Estamos en la vuelta (epoch) {numeroVuelta}")
    for i, x in enumerate(my_x_collection):
        print(x)
        respuesta=calcular_salida_xor(x, xorWeights, xorBias)
        salida_esperada = xorGoldOutputs[i]

        x_with_bias = [xorBias] + x
        salida_xor = sum(w * x for w, x in zip(xorWeights, x_with_bias))
    
        # Aplicar la función de activación (step function)
        prediccion= 1 if salida_xor >= 0 else -1
        
        # Mostrar la predicción y el valor esperado
        print(f"predictedOutput:{prediccion} Gold {xorGoldOutputs[i]}")
        print(respuesta)

        # Calcular el error
        error = xorGoldOutputs[i] - prediccion

        # Si hay error, ajustar los pesos
        if error != 0:
            notConverge = True  # No ha convergido, continuaremos entrenando
            print("AuxAct")  
            auxAct = [w + x for w, x in zip(xorWeights, respuesta)] # w'D = wD + f(x)
            print(auxAct)
            print("  Se han añadido pesos")
            print("#### matrix Average")
            lista_matrix = [xorWeights] + [auxAct]
            print(lista_matrix)
            print("####")
            print(xorWeights)
            operation = [w + x for w, x in zip(xorWeights, auxAct)]
            print(operation)
            print("acum")
            acum = matrixAverage([auxAct, xorWeights])
            print(acum)
            newWeights = acum
            print(newWeights)
            print("####")
            print(xorWeights)
            print(operation)
            xorWeights = matrixAverage([xorWeights, respuesta])
            print("acum")
            print(acum)
            # Mostrar pesos actualizados


# In[73]:


def xor_neuron(x):
    """
    Return x1_ * x2 + x1 * x2_
    """
    xor_w    = [-1.115635755887599, 0.3474337369372327, -0.7362253810233859]
    xor_bias = -0.5
    new_x=list()
    new_x.append(and_neuron(x))
    new_x.append(or_neuron(x))
    return neuron(new_x, xor_w, xor_bias)


# In[75]:


print('Checking XOR neuron output')
for my_x in my_x_collection:
    print(my_x, f'{xor_neuron(my_x):.3f}')


# In[ ]:




